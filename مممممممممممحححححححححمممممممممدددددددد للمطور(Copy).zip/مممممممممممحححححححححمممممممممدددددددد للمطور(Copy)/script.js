function uploadContent() {
    const category = document.getElementById("category").value;
    const file = document.getElementById("file").files[0];

    if (file) {
        // تخزين البيانات في المتصفح (قد تكون قاعدة بيانات أو واجهة API)
        const contentData = {
            category: category,
            file: file.name,
            fileUrl: URL.createObjectURL(file)
        };

        // إضافة المحتوى إلى القائمة
        const contentList = document.getElementById("content-list");
        const li = document.createElement("li");
        li.textContent = `القسم: ${category} - الملف: ${file.name}`;
        contentList.appendChild(li);

        // نشر المحتوى للمستخدمين (هنا مجرد محاكاة)
        updateUserView(contentData);
    }
}

function updateUserView(contentData) {
    const categoryContentList = document.getElementById(`${contentData.category.toLowerCase()}-content`);
    const li = document.createElement("li");

    const link = document.createElement("a");
    link.href = contentData.fileUrl;
    link.textContent = contentData.file;
    link.target = "_blank";
    
    li.appendChild(link);
    categoryContentList.appendChild(li);
}